namespace eis_core_net.Configuration
{
    public class Configuration
    {
        public const string BrokerConfig="BrokerConfig";

        public string BrokerUri {get; set; }
        public string BrokerTopic {get; set; }

    }
}