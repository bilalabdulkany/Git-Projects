using System;
namespace eis_core.Model
{   

public static class SourceSystemName
{
    public const string FLYING_PROCESS="FLYING_PROCESS";
    public const string MDM="MDM";
    public const string CURRENCY="CURRENCY";
    public const string PPMS="PPMS";
    public const string TRAINING="TRAINING";
    public const string SIMULATOR="SIMULATOR";
    public const string CRC="CRC";
    public const string CURRENT_AADMIS="CURRENT_AADMIS";

}

}