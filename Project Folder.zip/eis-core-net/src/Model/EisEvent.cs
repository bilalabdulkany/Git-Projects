  using System;
  using System.IO;
  using Amqp.Serialization;
  using Amqp.Types;

namespace eis_core.Model
{
  
    
    [AmqpContract] 
    public class EisEvent 
    {
        [AmqpMember]
        public string eventID{get;set;}
        [AmqpMember]
        public string eventType{get;set;}
        [AmqpMember]
        public DateTime createdDate {get;set;}
        [AmqpMember]
        public string sourceSystemName{get;set;}
        [AmqpMember]
        public string traceId {get;set;}
        [AmqpMember]
        public string spanId {get;set;}
        [AmqpMember]
        public Payload payload {get;set;}
        
        //TODO - Method Chaining
    }
}