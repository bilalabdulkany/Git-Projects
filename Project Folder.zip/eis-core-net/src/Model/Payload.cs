using System;
using Amqp.Serialization;
namespace eis_core.Model
{   
    [AmqpContract] 
    public class Payload
    {   
        [AmqpMember]
        public object Content {get;set;} 

        public Payload(){
        }

        public Payload(object content)
        {
            this.Content = content;
        }
    }
}