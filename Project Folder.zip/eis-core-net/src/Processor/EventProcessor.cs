 using Amqp;
 using System;
 using System.IO;
 using Amqp.Types;
 using eis_core.Model;
 using System.Threading;
 using Microsoft.Extensions.Configuration;


namespace eis_core
{
    public class EventProcessor : IDisposable
    {

        readonly string brokerUri;
        readonly string queueName;
        private bool isDisposed = false;

        private Connection _connection;
        private Session session;
        private ReceiverLink receiver;
        
        public EventProcessor()
        {
            var configurationBuilder = new ConfigurationBuilder();
            var path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
            configurationBuilder.AddJsonFile(path, false);

            var root = configurationBuilder.Build();
            IConfiguration brokerSection=root.GetSection("BrokerConfig");
            this.brokerUri = brokerSection.GetSection("BrokerUri").Value;
            this.queueName = brokerSection.GetSection("BrokerTopic").Value;
            CreateAsyncBrokerConnection();            
        }

         private async void CreateAsyncBrokerConnection()
        {
            Address brokerUrl = new Address(brokerUri);
            _connection = await Connection.Factory.CreateAsync(brokerUrl);
            session = new Session(_connection);
            
        }

        
        public void registerListener() 
         {
           Console.WriteLine("Starting listener");          
           
           receiver = new ReceiverLink(session, "receiver-link", this.queueName+"::SampleQueue");
           receiver.Start(
                20,
                 (link, message) =>
                {
                    
                    string eisEvent = message.GetBody<string>();

                    Console.WriteLine($"Receiving the message: {eisEvent}");
                   link.ReceiveAsync();
                receiver.Accept(message);
                });
                Thread.Sleep(2000);
           
           
           
         }

           /*
            ReceiverLink receiver = new ReceiverLink(session, "receiver-link", this.queueName);
			receiver.Start(
                3,
                (link, message) =>
                {
                    EisEvent eisEvent = message.GetBody<EisEvent>();

                    Console.WriteLine("eisEvent " + eisEvent.payload.Content);

                    link.Accept(message);
                
                });   */

         #region IDisposable Members

        public void Dispose()
        {
            if (!this.isDisposed)
            {
                receiver.CloseAsync();
                this.session.CloseAsync();
                this._connection.CloseAsync();
                this.isDisposed = true;
            }
        }
        #endregion
      }
    
}