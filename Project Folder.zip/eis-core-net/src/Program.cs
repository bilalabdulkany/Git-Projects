using System;
namespace eis_core
{
    public class Program
    {
        public EventPublisher _publisher;
        public EventProcessor _processor;

        public Program(){
            _publisher= new EventPublisher();
            _processor= new EventProcessor();

        }
        static void Main(string[] args)
        {
           string message="";

            Console.WriteLine("Starting to publish message to Topic...");
            Program runProgram = new Program();

            Console.WriteLine("Write a Message to Send:");
            message=Console.ReadLine();

            //runProgram.publisher.SendMessage("Message: " + message);
            runProgram._publisher.publish(message);
            
            Console.WriteLine("Message Sent!");
            runProgram._processor.registerListener();
            Console.WriteLine("Message Completed");


        }

    }
}