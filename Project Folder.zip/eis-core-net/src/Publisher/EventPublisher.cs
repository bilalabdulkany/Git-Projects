using System;
using System.Text;
using System.IO;
using Amqp;
using Amqp.Types;
using Amqp.Framing;
using Amqp.Serialization;
using Microsoft.Extensions.Configuration;
using eis_core.Model;
using System.Diagnostics;
namespace eis_core
{
    public class EventPublisher : IDisposable
    {
        private Connection _connection;
        private Session session;
        private bool isDisposed = false;
        private SenderLink sender;
        readonly string brokerUri;
        readonly string queueName;

        public EventPublisher()
        {

            Console.WriteLine("##Initializing MQ##");
            var configurationBuilder = new ConfigurationBuilder();
            var path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
            configurationBuilder.AddJsonFile(path, false);

            var root = configurationBuilder.Build();

            IConfiguration brokerSection = root.GetSection("BrokerConfig");
            this.brokerUri = brokerSection.GetSection("BrokerUri").Value;
            this.queueName = brokerSection.GetSection("BrokerTopic").Value;
            /***/
            //Address brokerUrl = new Address(brokerUri);
            //_connection = new Connection(brokerUrl);
            //session = new Session(_connection);
            CreateAsyncBrokerConnection();
           

        }

        private async void CreateAsyncBrokerConnection()
        {
            Address brokerUrl = new Address(brokerUri);
            _connection = await Connection.Factory.CreateAsync(brokerUrl);
            session = new Session(_connection);
            sender = new SenderLink(this.session, "sender-link", queueName);
        }
        public async void publish(string messagePublish)
        {

            Console.WriteLine("Trying to publish message...");
            Message message = new Message(messagePublish);
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();
            await sender.SendAsync(message);
            //sender.Send(message);
            watch.Stop();

            Console.WriteLine($"Message Sent! {watch.ElapsedMilliseconds} ms");

        }

        public void publish(IMessageProducer messageObject)
        {

            EisEvent eisEvent = this.getEisEvent(messageObject);
            //Message message = new Message(eisEvent);
            //message.Properties = new Properties() { MessageId = "id" };
            var message = new Message() { BodySection = new AmqpValue<EisEvent>(eisEvent) };

            sender.Send(message);
            Console.WriteLine("Sent Hello AMQP!");

        }


        private EisEvent getEisEvent(IMessageProducer messageProducer)
        {
            EisEvent eisEvent = new EisEvent();
            eisEvent.eventID = Guid.NewGuid().ToString();
            eisEvent.eventType = messageProducer.getEventType();
            eisEvent.traceId = messageProducer.getTraceId();
            eisEvent.spanId = Guid.NewGuid().ToString();
            eisEvent.createdDate = DateTime.Now;
            eisEvent.sourceSystemName = SourceSystemName.FLYING_PROCESS;//TODO get the name from properies
            eisEvent.payload = messageProducer.getPayLoad();
            return eisEvent;
        }


        #region IDisposable Members

        public void Dispose()
        {
            if (!this.isDisposed)
            {
                this.sender.Close();
                this.session.Close();
                this._connection.Close();
                this.isDisposed = true;
            }
        }
        #endregion
    }
}