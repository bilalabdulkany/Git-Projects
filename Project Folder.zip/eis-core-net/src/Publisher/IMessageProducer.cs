using System;

namespace eis_core.Model
{   
   
    public  interface IMessageProducer
    { 
      
        Payload getPayLoad();       
         string getEventType();
         
         string getTraceId();
    }

/*    static class GetDefaultTraceID
{
    public static string FormattedNameDefault()
    {
        return Guid.NewGuid().ToString();
    }
}*/

}