﻿using System;
//using System.Web.Http;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using eis_core;

namespace EventPublisherApi.Controllers
{
   [ApiController]
   [Route("[controller]")]
    public class EventPublisherController : ControllerBase
    {

        private EventPublisher _eventPublisher;
        private EventProcessor _eventProcessor;

        

       // private readonly ILogger<WeatherForecastController> _logger;

        public EventPublisherController(EventPublisher eventPublisher,EventProcessor eventProcessor)
        {

          this._eventPublisher=eventPublisher;
          this._eventProcessor=eventProcessor;
        }

        [HttpPost("message")]       
        public IActionResult Publish(string message)
        {
            Console.WriteLine($"###---------Printing {message} -------###");
            try{
            _eventPublisher.publish(message);
            }catch(Exception e){
                Console.WriteLine(e);
            }
            return Ok(message);
        }

        [HttpGet]
        public IActionResult Consume(){
            Console.WriteLine("##Consuming Message##");
            _eventProcessor.registerListener();
            return Ok();
        }


       
    }
}
