using eis_core.Model;

namespace event_publisher_net
{  
    public class MessageProducerImpl : IMessageProducer
    {    

         public Payload getPayLoad(){
             return new Payload("Content");
         }

         public string getEventType(){
             return "Model";
         }
         public string getTraceId(){
             return "123";
         }
    }
}