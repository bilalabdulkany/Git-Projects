package com.simpledev.oauthresource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthResourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
